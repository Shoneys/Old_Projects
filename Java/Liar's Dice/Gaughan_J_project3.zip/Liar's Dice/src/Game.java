import java.util.ArrayList;

class Game implements Playable {
    /*
    Game.Java
        implements the methods in Interface Playable.
        Holds the Game loop.
        Assigns AI to dumb or smart computer.

        ArrayList alldice: concatenates player1 and player2's dice in to one list. It is stored within Player1, as that is who is checked when Player2 calls bluff
        DumbComputerBidTurn: chooses randomly
        SmartComputerBidTurn: chooses based on number of dice in hand
        HumanBidTurn: allows human to bid

        dumbComputerLIARTurn: chooses randomly
        smartComputerLIARTurn: chooses to call bluff based on number of dice opponent calls, or raise its guessed number of dice by 1 (Low effort solution)
        humanLIARTurn: allows human to raise (split in to separate methods facevalueChange and numberofdiceChange) or call bluff
        callBluff: checkBluff is handled within in Player Object
     */
    Boolean gameON = true;
    ArrayList alldice = new ArrayList();

    public void runningtheGame(Player player1, Player player2) {
        alldice.add(player1.dicevalues);
        alldice.add(player2.dicevalues);
        player1.allDice = alldice;

        while (gameON != false) {
            System.out.println("For this turn, we are starting with: " + player1.gettype());
            if (player1.type == 1) {
                dumbComputerBidTurn(player1);
            } else if (player1.type == 2) {
                smartComputerBidTurn(player1);
            } else if (player1.type == 3) {
                humanBidTurn(player1);
            }
            System.out.println("The second mover is: " + player2.gettype());
            if (player2.type == 1) {
                dumbComputerLIARTurn(player1, player2);
            } else if (player2.type == 2) {
                smartComputerLIARTurn(player1, player2);
            } else if (player2.type == 3) {
                humanLIARTurn(player1, player2);
            }
            System.out.println("\n***Next Round!***\n");
            runningtheGame(player2, player1);
        }
    }

    public void dumbComputerBidTurn(Player player) {
        player.facevalue = (int) (Math.random() * 6) + 1;
        player.numofdice = (int) (Math.random() * alldice.size()) + 1;
        System.out.println("I, DUMB COMPUTER, BID: " + player.numofdice + " " + player.facevalue + "'s");
    }

    public void smartComputerBidTurn(Player player) {
        player.getFV();
        player.facevalue = player.smartcompFV;
        player.numofdice = player.smartcompND;
        System.out.println("I, Smart Computer, bid: " + player.numofdice + " " + player.facevalue + "'s");
    }

    public void humanBidTurn(Player player) {
        System.out.println("The human's dice are: " + player.getDice());
        System.out.println("Human, enter your Bid for face value (1-6): ");
        player.facevalue = MMenu.in.nextInt();
        if (player.facevalue < 1 || player.facevalue > 6) {
            System.out.println("Please enter a valid range!");
            humanBidTurn(player);
        }
        System.out.println("Human, enter min number of dice (1-5): ");
        player.numofdice = MMenu.in.nextInt();
        if (player.numofdice < 1 || player.numofdice > 5) {
            System.out.println("Please enter a valid range!");
            humanBidTurn(player);
        }
    }


    public void dumbComputerLIARTurn(Player player1, Player player2) {
        System.out.println("I MAKE RANDOM ACCUSATIONS");
        int d2 = (int) (Math.random() * 2) + 1;
        if (d2 == 1) {
            player2.numofdice = (int) (Math.random() * 5) + player2.numofdice + 1;
            System.out.println("I RAISE TO: " + player2.numofdice + " " + player2.facevalue + "'s");
        } else {
            System.out.println("I CALL BLUFF!");
            callBluff(player1, player2);
        }
    }

    public void smartComputerLIARTurn(Player player1, Player player2) {
        if (player1.numofdice > 4) {
            callBluff(player1, player2);
        } else { //raises 1 die if other player is not suspicious enough
            player2.numofdice += 1;
            System.out.println("Smart computer raises to: " + player2.numofdice);
        }

    }

    public void humanLIARTurn(Player player1, Player player2) {
        System.out.println("Do you raise or call Bluff? (1=Raise, 2=Call Bluff): ");
        int betorbluff = MMenu.in.nextInt();

        if (betorbluff == 1) {
            System.out.println("Want to raise face value, number of dice, or both? (1=Face Value, 2=Number of Dice, 3=Both)");
            int raisechoice = MMenu.in.nextInt();
            if (raisechoice == 1) {
                facevalueChange(player2);
            } else if (raisechoice == 2) {
                numberofdiceChange(player2);
            } else if (raisechoice == 3) {
                facevalueChange(player2);
                numberofdiceChange(player2);
            }

        } else if (betorbluff == 2) {
            callBluff(player1, player2);
        }
    }

    public void facevalueChange(Player player) {
        System.out.println("Enter how much you raise face value: ");
        int temp = MMenu.in.nextInt();

        if (temp >= player.facevalue || temp <= 6) {
            player.facevalue = temp;
        } else {
            System.out.println("Please enter a value equal to or larger than: " + player.facevalue);
            facevalueChange(player);
        }
    }

    public void numberofdiceChange(Player player) {
        System.out.println("Enter how much you raise number of dice, or stay: ");
        int temp = MMenu.in.nextInt();
        if (temp >= player.numofdice || temp <= alldice.size()) {
            player.numofdice = temp;
        } else {
            System.out.println("Please enter a value equal to or larger than: " + player.numofdice);
            numberofdiceChange(player);
        }

    }

    public void callBluff(Player player1, Player player2) {
        System.out.println("\n"+player2.gettype() + " calls bluff!");
        System.out.println(player1.gettype() + "'s dice: " + player1.getDice());
        System.out.println(player2.gettype() + "'s dice: " + player2.getDice());
        if (player1.checkBluff() == true) {
            System.out.println(player1.gettype() + " is wrong!");
            System.out.println(player2.gettype() + " is a winner!");
        } else if (player1.checkBluff() == false) {
            System.out.println(player1.gettype() + " is a winner!");
            System.out.println(player2.gettype() + " is wrong!");
        }
        System.exit(0);
    }
}
