import java.util.ArrayList;
import java.util.Collections;

public class Player {
    /*
    Player.java
        Object that describes a Player
        Can be computer or human
        Stores instance variables and handles the checkBluff

        getFV: used for smartComp, assigns most frequent value to the computer's guesses
        gettype: returns type of player
        getDice: returns dice arraylist
        generateDice: generates Dice
        checkBluff: most important part of program, checks if a player's bluff has been called
     */
    int type;
    int facevalue;
    int numofdice;
    int smartcompND;
    int smartcompFV;
    ArrayList dicevalues = generateDice();
    ArrayList allDice;

    void getFV() {
        int index = 1;
        int freq = 0;
        int tempFV = 0;
        int tempNoD = 0;
        for (Object o : dicevalues) {
            freq = Collections.frequency(dicevalues, index);
            if (freq > tempNoD) {
                tempFV = index;
                tempNoD = freq;
            }
            if (index == dicevalues.size()) {
                smartcompFV = tempFV;
                smartcompND = tempNoD;
            }
            index++;
        }
    }

    String gettype() {
        if (type == 1) {
            return "Dumb Computer";
        } else if (type == 2) {
            return "Smart Computer";
        } else if (type == 3) {
            return "Human";
        }
        return null;
    }

    ArrayList getDice() {
        return dicevalues;
    }

    ArrayList generateDice() {
        ArrayList tempvalues = new ArrayList();
        int index = 0;
        while (index <= 5) {
            tempvalues.add((int) (Math.random() * 6) + 1);
            index++;
        }
        return tempvalues;

    }

    Boolean checkBluff() {

        int z = 0, index = 0;
        for (Object O : allDice) {
            if (allDice.get(index).equals(facevalue)) {
                z++;
                if (z >= numofdice) {
                    return true;
                }
            }
            index++;
        }
        return false;

    }

}
